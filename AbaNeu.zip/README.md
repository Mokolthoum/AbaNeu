# VulnBank - Vulnerable Banking Application

> ⚠️ هذا التطبيق مُعد للاختبار الأمني فقط. لا تقم بنشره على سيرفر عام!

## المتطلبات الأساسية

- **Python 3.10+** (تأكد من تثبيته: `python3 --version`)

## خطوات التشغيل

### 1. فك الضغط والدخول للمجلد
```bash
unzip AbaNeu.zip
cd AbaNeu
```

### 2. إنشاء بيئة افتراضية وتفعيلها
```bash
python3 -m venv venv
source venv/bin/activate
```
> على Windows استخدم: `venv\Scripts\activate`

### 3. تثبيت المكتبات
```bash
pip install -r requirements.txt
```

### 4. إنشاء قاعدة البيانات
```bash
python manage.py migrate
```

### 5. إضافة البيانات التجريبية (مستخدمين وحسابات)
```bash
python seed_data.py
```

### 6. تشغيل السيرفر
```bash
python manage.py runserver 8000
```

### 7. فتح التطبيق
افتح المتصفح على: **http://localhost:8000**

## بيانات الدخول

| المستخدم | اسم المستخدم | كلمة المرور | الصلاحية |
|---|---|---|---|
| Admin | `admin` | `admin123` | مدير النظام |
| John | `john` | `password123` | مستخدم عادي |
| Jane | `jane` | `password123` | مستخدم عادي |
